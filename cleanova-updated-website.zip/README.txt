CLEANOVA UPDATED WEBSITE

Files included:
- index.html
- commercial.html
- residential.html
- about.html
- quote.html
- styles.css
- script.js
- cleanova-hero.png

IMPORTANT:
Copy your existing logo-side.png and logo2.png into this same folder before publishing.
The quote form still contains the placeholder Formspree URL YOUR_FORMSPREE_ID; replace it with your real Formspree endpoint.
